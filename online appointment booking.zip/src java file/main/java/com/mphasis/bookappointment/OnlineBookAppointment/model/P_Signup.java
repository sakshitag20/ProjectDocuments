package com.mphasis.bookappointment.OnlineBookAppointment.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="patient_signup")
public class P_Signup {

	@Id
	@GeneratedValue
	@Column(name="p_id")
	private int p_id;
	
	@Column(name="p_name")
	private String p_Name;
	
	@Column(name="dob")
	@Temporal(TemporalType. DATE) 
	private Date dob;
	
	@Column(name="p_gender")
	private String p_gender;
	
	@Column(name="p_contact_no")
	private int p_contact_no;
	
	@Column(name="p_username")
	private String p_username;
	
	@Column(name="p_password")
	private String p_password;

	public P_Signup(int p_id, String p_Name, Date dob, String p_gender, int p_contact_no, String p_username, String p_password) {
		super();
		this.p_id = p_id;
		this.p_Name = p_Name;
		this.dob = dob;
		this.p_gender = p_gender;
		this.p_contact_no = p_contact_no;
		this.p_username = p_username;
		this.p_password = p_password;
	}
	
	public P_Signup()
	{
		
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getP_Name() {
		return p_Name;
	}

	public void setP_Name(String p_Name) {
		this.p_Name = p_Name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getP_gender() {
		return p_gender;
	}

	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}

	public int getP_contact_no() {
		return p_contact_no;
	}

	public void setP_contact_no(int p_contact_no) {
		this.p_contact_no = p_contact_no;
	}

	public String getP_username() {
		return p_username;
	}

	public void setP_username(String p_username) {
		this.p_username = p_username;
	}

	public String getP_password() {
		return p_password;
	}

	public void setP_password(String p_password) {
		this.p_password = p_password;
	}
		
}
