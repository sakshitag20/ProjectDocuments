export class Appointment{
    p_id:number=0;
    p_aname:string="";
    p_amid:string="";
    city:string="";
    gender:string="";
    d_id:number=0;
    ap_id:number=0;
    ap_date:string='';
    ap_time:string='';
}