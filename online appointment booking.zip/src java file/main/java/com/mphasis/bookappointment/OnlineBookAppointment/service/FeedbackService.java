package com.mphasis.bookappointment.OnlineBookAppointment.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.bookappointment.OnlineBookAppointment.dao.FeedbackRepository;
import com.mphasis.bookappointment.OnlineBookAppointment.model.Feedback;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository fRepository;
	
	@Transactional
	public List<Feedback> fetchFeedbacks() {
		List<Feedback> fList=fRepository.findAll();
		return fList;
		
	}
	@Transactional
	public Feedback saveFeedback(Feedback feedback) {
		
		return fRepository.save(feedback);
		
	}
	@Transactional
	public void updateFeedback(Feedback f) {
		fRepository.save(f);	
	
	}
	
	@Transactional
	public void deleteFeedback(int p_Id) {
		//empRepository.delete(f);	
		System.out.println("service method called");
		fRepository.deleteById(p_Id);
	
	}
	@Transactional 
	  public Feedback getFeedback(int p_id) { 
	  Optional<Feedback> optional= fRepository.findById(p_id);
	  Feedback f=optional.get();
	  return f;
	  

}
}
