package com.mphasis.bookappointment.OnlineBookAppointment.dao;

import java.util.Collection;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.bookappointment.OnlineBookAppointment.model.Disease;

@Repository

public interface DiseaseRepository extends JpaRepository<Disease ,Integer>  {
//	@Query("SELECT e FROM Employee e WHERE e.status =?1") JPQL
//	Collection<Employee> findAllActiveEmployees();
	
}


