package com.mphasis.bookappointment.OnlineBookAppointment.dao;

import java.util.Collection;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.bookappointment.OnlineBookAppointment.model.Doctor;


@Repository
public interface DoctorRepository extends JpaRepository<Doctor ,Integer>{
	@Query("SELECT a FROM Doctor a WHERE a.mail_id =?1 and a.d_password=?2")
	public Doctor validateUser(String d_name,String d_password);
}
