package com.mphasis.bookappointment.OnlineBookAppointment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class Feedback {
	@Id
	@GeneratedValue
	@Column(name="p_id")
	private int p_id;
	@Column(name="f_name")
	private String f_Name;
	@Column(name="l_name")
	private String l_Name;
	@Column(name="mail")
	private String mailId;
        @Column(name="phone_no")
	private String phone_no;
        @Column(name="address")
        private String address;
        @Column(name="pcomment")
        private String pcomment;
         public Feedback(int p_id,String f_Name, String l_Name, String mailId, String phone_no, String address, String pcomment) {
        super();
        this.p_id=p_id;
        this.f_Name = f_Name;
        this.l_Name = l_Name;
        this.mailId = mailId;
        this.phone_no = phone_no;
        this.address = address;
        this.pcomment = pcomment;
    }
	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getp_Id() {
		return p_id;
	}
	public void setp_Id(int p_id) {
		this.p_id = p_id;
	}
	public String getF_Name() {
		return f_Name;
	}
	public void setF_Name(String f_Name) {
		this.f_Name = f_Name;
	}
	public String getL_Name() {
		return l_Name;
	}
	public void setL_Name(String l_Name) {
		this.l_Name = l_Name;
	}
	public String getmailId() {
		return mailId;
	}
	public void setmailId(String mailId) {
		this.mailId = mailId;
	}
        
	public String getphone_no() {
		return phone_no;
	}
	public void setphone_no(String phone_no) {
		this.phone_no = phone_no;
	}
        
         public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
        
        public String getpcomment() {
		return pcomment;
	}
	public void setpcomment(String pcomment) {
		this.pcomment = pcomment;
	}
        
       
}



