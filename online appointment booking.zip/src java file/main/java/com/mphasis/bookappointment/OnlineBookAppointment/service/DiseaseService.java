package com.mphasis.bookappointment.OnlineBookAppointment.service;

import java.util.List;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.bookappointment.OnlineBookAppointment.dao.DiseaseRepository;
import com.mphasis.bookappointment.OnlineBookAppointment.model.Disease;

@Service
public class DiseaseService {
	@Autowired
	DiseaseRepository disRepository;
	
	@Transactional
	public List<Disease> fetchDiseases() {
		List<Disease> disList=disRepository.findAll();
		return disList;
		
	}
	@Transactional
	public Disease saveDisease(Disease disease) {
		
		return disRepository.save(disease);
		
	}
	@Transactional
	public void updateDisease(Disease dis) {
		disRepository.save(dis);	
	
	}
	
	@Transactional
	public void deleteDisease(int disId) {
		//empRepository.delete(dis);	
		System.out.println("service method called");
		disRepository.deleteById(disId);
	
	}
	@Transactional 
	  public Disease getDisease(int id) { 
	  Optional<Disease> optional= disRepository.findById(id);
	  Disease dis=optional.get();
	  return dis;
	  

}
}

