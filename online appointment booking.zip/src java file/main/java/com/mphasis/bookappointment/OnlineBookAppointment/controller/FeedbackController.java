package com.mphasis.bookappointment.OnlineBookAppointment.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.bookappointment.OnlineBookAppointment.exception.ResourceNotFoundException;
import com.mphasis.bookappointment.OnlineBookAppointment.model.Feedback;
import com.mphasis.bookappointment.OnlineBookAppointment.service.FeedbackService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class FeedbackController {

	@Autowired
	FeedbackService fService;

//http://localhost:8090/api/v1/getAllFeedbacks
	@GetMapping("/getAllFeedbacks")
	public List<Feedback> getFeedbacks() {
		List<Feedback> fList = fService.fetchFeedbacks();

		return fList;

	}

	// http://localhost:8090/api/v1/getFeedback/1
	@GetMapping("/getFeedback/{p_id}")
	public ResponseEntity<Feedback> getFeedbackById(@PathVariable("p_id") int p_id)
			throws ResourceNotFoundException {
		Feedback feedback = fService.getFeedback(p_id);
		return ResponseEntity.ok().body(feedback);
	}

	// http://localhost:8090/api/v1/saveFeedback
	@PostMapping("/saveFeedback")
	public com.mphasis.bookappointment.OnlineBookAppointment.model.Feedback addFeedback(@RequestBody Feedback f) {

		Feedback feedback = fService.saveFeedback(f);

		// return new ResponseEntity<>("Feedback added successsfully", HttpStatus.OK);
		return feedback;
	}

	// http://localhost:8090/api/v1/updateFeedback/2
	@PutMapping("/updateFeedback/{p_id}")
	public ResponseEntity<Feedback> updateFeedback(@PathVariable("p_id") int p_id,
			@RequestBody Feedback feedbackDetails) throws ResourceNotFoundException {
		Feedback feedback = fService.getFeedback(p_id);

		feedback.setmailId(feedbackDetails.getmailId());
		feedback.setL_Name(feedbackDetails.getL_Name());
		feedback.setF_Name(feedbackDetails.getF_Name());
                feedback.setphone_no(feedbackDetails.getphone_no());
                feedback.setaddress(feedbackDetails.getaddress());
                feedback.setpcomment(feedbackDetails.getpcomment());
		final Feedback updatedFeedback = fService.saveFeedback(feedback);
		return ResponseEntity.ok(updatedFeedback);
	}

//http://localhost:8090/api/v1/deleteFeedback/1
	@DeleteMapping(value = "/deleteFeedback/{p_id}")
	public ResponseEntity<Object> deleteFeedback(@PathVariable("p_id") int p_id) {

		fService.deleteFeedback(p_id);
		return new ResponseEntity<>("Feedback deleted successsfully", HttpStatus.OK);
	}
	

}





