package com.mphasis.bookappointment.OnlineBookAppointment.model;

import javax.persistence.Column;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="disease")
public class Disease {

	@Id
	@GeneratedValue
	@Column(name="di_id")
	private int id;
	@Column(name="d_name")
	
	private String dName;
	@Column(name="d_symptoms")
	private String dsymptoms;
	@Column(name="d_type")
	private String dtype;
	public Disease(String dName, String dsymptoms, String dtype) {
        super();
        this.dName = dName;
        this.dsymptoms = dsymptoms;
        this.dtype = dtype;
  
	}
   public Disease()
    {
	   
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public String getDsymptoms() {
		return dsymptoms;
	}
	public void setDsymptoms(String dsymptoms) {
		this.dsymptoms = dsymptoms;
	}
	public String getDtype() {
		return dtype;
	}
	public void setDtype(String dtype) {
		this.dtype = dtype;
	}
}