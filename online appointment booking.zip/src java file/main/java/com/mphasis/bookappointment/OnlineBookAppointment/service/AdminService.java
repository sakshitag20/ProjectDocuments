package com.mphasis.bookappointment.OnlineBookAppointment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.bookappointment.OnlineBookAppointment.dao.AdminRepository;
import com.mphasis.bookappointment.OnlineBookAppointment.model.Admin;



@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;

	public Admin validateUser(Admin user) {
		Admin u=adminRepository.validateUser(user.getUsername(),user.getPassword());
		
		return u;
	}
	
}
