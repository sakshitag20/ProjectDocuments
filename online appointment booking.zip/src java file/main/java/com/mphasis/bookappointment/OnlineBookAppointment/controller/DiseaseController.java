package com.mphasis.bookappointment.OnlineBookAppointment.controller;

import java.util.HashMap;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.bookappointment.OnlineBookAppointment.exception.ResourceNotFoundException;
import com.mphasis.bookappointment.OnlineBookAppointment.model.Disease;
import com.mphasis.bookappointment.OnlineBookAppointment.service.DiseaseService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class DiseaseController {
	@Autowired
	DiseaseService disService;

//http://localhost:8090/api/v1/getAllDiseases
	@GetMapping("/getAllDiseases")
	public List<Disease> getDiseases() {
		List<Disease> disList = disService.fetchDiseases();

		return disList;

	}

	// http://localhost:8090/api/v1/getDisease/98
	@GetMapping("/getDisease/{diseaseId}")
	public ResponseEntity<Disease> getDiseaseById(@PathVariable("diseaseId") int diseaseId)
			throws ResourceNotFoundException {
		Disease disease = disService.getDisease(diseaseId);
		return ResponseEntity.ok().body(disease);
	}

	// http://localhost:8090/api/v1/saveDisease
	@PostMapping("/saveDisease")
	public Disease addDisease(@RequestBody Disease dis) {

		Disease disease = disService.saveDisease(dis);

		// return new ResponseEntity<>("Disease added successsfully", HttpStatus.OK);
		return disease;
	}

	// http://localhost:8090/api/v1/updateDisease/88
	@PutMapping("/updateDisease/{id}")
	public ResponseEntity<Disease> updateDisease(@PathVariable("id") int diseaseId,
			@RequestBody Disease diseaseDetails) throws ResourceNotFoundException {
		Disease disease = disService.getDisease(diseaseId);

		disease.setId(diseaseDetails.getId());
		disease.setdName(diseaseDetails.getdName());
		disease.setDsymptoms(diseaseDetails.getDsymptoms());
		disease.setDtype(diseaseDetails.getDtype());
		final Disease updatedDisease = disService.saveDisease(disease);
		return ResponseEntity.ok(updatedDisease);
	}

//http://localhost:8090/api/v1/deleteDisease/93
	@DeleteMapping(value = "/deleteDisease/{diseaseId}")
	public ResponseEntity<Object> deleteDisease(@PathVariable("diseaseId") int disId) {

		disService.deleteDisease(disId);
		return new ResponseEntity<>("Disease deleted successsfully", HttpStatus.OK);
	}
	

}



